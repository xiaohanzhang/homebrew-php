#define PHP_ICONV_H_PATH </Library/Developer/CommandLineTools/SDKs/MacOSX10.14.sdk/usr/include/iconv.h>
